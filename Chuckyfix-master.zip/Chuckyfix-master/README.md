# Chuckyfix
BOT PROTECT CREATOR & ADMIN & 5 BOT + 1 GHOST.
------
GET TOKEN :
------
- `Bot Alphat : https://github.com/Nadyatjia/AlphatTJ`
-
Cara Install Bot Chucky :
------
Di C9 :
- Ketik -> `sudo apt-get update`
- Ketik -> `sudo apt-get install git`
- Ketik -> `sudo apt-get install python-sofware-properties`
- Ketik -> `sudo pip install rsa`
- Ketik -> `sudo pip install thrift==0.9.3`
- Ketik -> `sudo pip install requests`
- Ketik -> `sudo pip install requests==2.5.3`
- Ketik -> `sudo pip install bs4`
- Ketik -> `sudo pip install gtts`
- Ketik -> `sudo pip install googletrans`
- Ketik -> `git clone https://github.com/Nadyatjia/Chuckyfix`
- Ketik -> `cd Chucky`
- Ketik -> `python Chucky.py`

Di Termux :
- Ketik -> `pkg update`
- Ketik -> `pkg install git`
- Ketik -> `pkg install python2`
- Ketik -> `pip2 install rsa`
- Ketik -> `pip2 install thrift==0.9.3`
- Ketik -> `pip2 install requests`
- Ketik -> `pip2 install bs4`
- Ketik -> `pip2 install gtts`
- Ketik -> `pip2 install googletrans`
- Ketik -> `git clone https://github.com/Nadyatjia/Chuckyfix`
- Ketik -> `cd Chucky`
- Ketik -> `python2 Chucky.py`

Cara Menjalankan Bot Kembali :
------
Di C9 :
- Ketik -> `cd Chucky`
- Ketik -> `python Chucky.py`

Di Termux :
- Ketik -> `cd Chucky`
- Ketik -> `python2 Chucky.py`


Credit By@ Nadya Sutjiadi.
------
- `Follow My Instagram : nadya.tjia`
- `Add My ID LINE : nad_nad. (pake titik)`

Thx To :
------
- `LINE-TCR TEAM`

